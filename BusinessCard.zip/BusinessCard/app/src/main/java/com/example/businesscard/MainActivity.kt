package com.example.businesscard

import android.media.metrics.BundleSession
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.businesscard.ui.theme.BusinessCardTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BusinessCardTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CardApp()
                }
            }
        }
    }
}


@Composable
fun BusinessCard(logo: Painter,
                         name: String,
                         title: String,
                         phone: String,
                         socialMedia: String,
                         email: String) {
    Column(
           modifier = Modifier
              .fillMaxWidth()
              .height(650.dp)
              .background(color = Color.Black)
              .padding(top = 150.dp),
           horizontalAlignment = Alignment.CenterHorizontally,
           verticalArrangement = Arrangement.Center

          

    ) {
        Image(
            painter = logo,
            contentDescription = null,
            modifier = Modifier
                .height(120.dp)
                .width(150.dp)
        )
        Text(
            text = name,
            color = Color.White
        )
        Text(
            text = title,
            color = Color.White
        )

        Spacer(modifier = Modifier.weight(1f))
    }
    Column (
        modifier = Modifier

            .fillMaxWidth()
            .padding(top = 500.dp)
        ,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom
    ){
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 40.dp),
        ){
            Icon(painter = painterResource(id = R.drawable.phone),
                contentDescription = null,
                modifier = Modifier.padding(start = 60.dp),
                tint = Color(61,220,132))
            Text(text = phone , color = Color.White)
        }
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 40.dp),
        ){
            Icon(painter = painterResource(id = R.drawable.social), contentDescription = null, modifier = Modifier.padding(start = 60.dp), tint = Color(61,220,132) )
            Text(text = socialMedia , color = Color.White)
        }
        Row (
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 40.dp),
        ){
            Icon(painter = painterResource(id = R.drawable.email), contentDescription = null, modifier = Modifier.padding(start = 60.dp), tint = Color(61,220,132))
            Text(text = email , color = Color.White)
        }



    }

}

@Composable
fun CardApp() {
    BusinessCard(
        logo = painterResource(id = R.drawable.android_logo),
        name = "Amal Jawahdou",
        title = "Android Development Learner",
        phone = "+(216) xxxxxxxx",
        socialMedia = "@amaljw146",
        email = "amaljw2002@gmail.com")


}


@Preview(showBackground = true)
@Composable
fun BusinessCardPreview() {
    BusinessCardTheme {
        Surface {
            CardApp()
        }
    }
}